-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2020 at 11:17 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_android`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_karyawan`
--

CREATE TABLE `t_karyawan` (
  `id` int(12) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `gaji` varchar(15) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `t_karyawan`
--

INSERT INTO `t_karyawan` (`id`, `nama`, `jabatan`, `gaji`, `email`, `photo`) VALUES
(1, 'Andi Malarangeng', 'Manajer', '12000000', 'andimalang@gmail.com', 'http:///192.168.100.4/andi_malarangeng.jpg'),
(2, 'Luhut Panjaitan', 'Supervisor', '10000000', 'luhutpanja@gmail.com', 'http://192.168.100.4/android/images/luhut_panjaitan.jpg'),
(3, 'Amien Rais', 'Asisten Manajer', '10500000', 'amienamin@yahoo.com', 'http://192.168.100.4/android/images/amien_rais.jpg'),
(4, 'Akbar Tanjung', 'Sekretaris', '9000000', 'akbarnjung@gmail.com', 'http://192.168.100.4/android/images/akbar_tanjung.jpg'),
(5, 'Budiono', 'Kasir', '7000000', 'budionok@gmail.com', 'http://192.168.100.4/android/images/budiono.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_karyawan`
--
ALTER TABLE `t_karyawan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_karyawan`
--
ALTER TABLE `t_karyawan`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php 


	$id = $_GET['id'];
	

	require_once('koneksi.php');
	

	$sql = "SELECT * FROM t_karyawan WHERE id=$id";
	

	$r = mysqli_query($con,$sql);
	
	$result = array();
	$row = mysqli_fetch_array($r);
	array_push($result,array(
			"id"=>$row['id'],
			"name"=>$row['nama'],
			"desg"=>$row['jabatan'],
			"salary"=>$row['gaji'],
			"email"=>$row['email'],
			"photo"=>$row['photo']
		));


	echo json_encode(array('result'=>$result));
	
	mysqli_close($con);
?>
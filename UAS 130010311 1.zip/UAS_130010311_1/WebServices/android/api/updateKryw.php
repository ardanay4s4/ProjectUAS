<?php 

	if($_SERVER['REQUEST_METHOD']=='POST'){

		$id = $_POST['id'];
		$name = $_POST['name'];
		$desg = $_POST['desg'];
		$sal = $_POST['salary'];
		$email = $_POST['email'];
		$photo = $_POST['photo'];
		

		require_once('koneksi.php');
		

		$sql = "UPDATE t_karyawan SET nama = '$name', jabatan = '$desg', gaji = '$sal', email = '$email', photo = '$photo' WHERE id = $id;";
		
 
		if(mysqli_query($con,$sql)){
			echo 'Berhasil Update Data Pegawai';
		}else{
			echo 'Gagal Update Data Pegawai';
		}
		
		mysqli_close($con);
	}
?>
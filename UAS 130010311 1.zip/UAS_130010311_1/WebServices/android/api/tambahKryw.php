<?php


	if($_SERVER['REQUEST_METHOD']=='POST'){
		
		
		$name = $_POST['name'];
		$desg = $_POST['desg'];
		$sal = $_POST['salary'];
		$email = $_POST['email'];
		$photo = $_POST['photo'];
		
		$sql = "INSERT INTO t_karyawan (nama, jabatan, gaji, email, photo) VALUES ('$name','$desg','$sal','$email','$photo')";
		
		require_once('koneksi.php');
		
		if(mysqli_query($con,$sql)){
			echo 'Berhasil Menambahkan Data Pegawai';
		}else{
			echo 'Gagal Menambahkan Data Pegawai';
		}
		
		mysqli_close($con);
	}
?>
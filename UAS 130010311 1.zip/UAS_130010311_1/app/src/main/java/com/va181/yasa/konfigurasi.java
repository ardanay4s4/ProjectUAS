package com.va181.yasa;

public class konfigurasi {

    public static final String URL_ADD = "http://192.168.100.4/android/api/tambahKryw.php";
    public static final String URL_GET_ALL = "http://192.168.100.4/android/api/tampilSemuaKryw.php";
    public static final String URL_GET_EMP = "http://192.168.100.4/android/api/tampilKryw.php";
    public static final String URL_UPDATE_EMP = "http://192.168.100.4/android/api/updateKryw.php";
    public static final String URL_DELETE_EMP = "http://192.168.100.4/android/api/hapusKryw";


    public static final String KEY_EMP_ID = "id";
    public static final String KEY_EMP_NAMA = "name";
    public static final String KEY_EMP_JABATAN = "desg";
    public static final String KEY_EMP_GAJI = "salary";
    public static final String KEY_EMP_EMAIL = "email";
    public static final String KEY_EMP_PHOTO = "photo";

    
    public static final String TAG_JSON_ARRAY="result";
    public static final String TAG_ID = "id";
    public static final String TAG_NAMA = "name";
    public static final String TAG_JABATAN = "desg";
    public static final String TAG_GAJI = "salary";
    public static final String TAG_EMAIL = "email";
    public static final String TAG_PHOTO = "photo";


    public static final String EMP_ID = "emp_id";
}
